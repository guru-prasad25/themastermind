This is a simple text based quizzing program written in python
The quiz consists of 5 questions.
The initial score is set to zero and incremented by 1 with every correct answer.
The final score is displayed after the end of the quiz.
Time delays are used in places to improve readability.
The answer obtained as input is converted to lowercase to remove the need for case sensitivity.
If loops are used to determine the correct answers with some questions using in operator to find keywords in answer. 
